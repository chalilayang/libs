Library Project including compatibility IntrumentationTestRunner
for multiple dex applications.

This can be used by an Android test project to set up the classloader
of applications with multiple dexes.

There is technically no source, but the src folder is necessary
to ensure that the build system works.  The content is actually
located in libs/android-support-multidex-instrumentation.jar.

